package com.rfm.rfmApi.models;

public class OffshoreWorkingDays {

    public static final int JANUARY = 21;
    public static final int FEBRUARY = 20;
    public static final int MARCH = 21;
    public static final int APRIL = 21;
    public static final int MAY = 22;
    public static final int JUNE = 19;
    public static final int JULY = 23;
    public static final int AUGUST = 21;
    public static final int SEPTEMBER = 20;
    public static final int OCTOBER = 20;
    public static final int NOVEMBER = 16;
    public static final int DECEMBER = 15;

}
