package com.rfm.rfmApi.enums;

public enum AllocationType {

    BASELINE, MOSTLIKELY, UPSIDE
}
